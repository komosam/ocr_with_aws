def data_extractor_lambda(event, context):
  print("Functioning")