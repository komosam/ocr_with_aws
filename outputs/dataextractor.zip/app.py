def helper(event, context):
  print(event)
  print("Functioning")